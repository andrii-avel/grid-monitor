#!/bin/sh
echo "Hello BLAST!"

# define the sequence database name
dbname="uniprot_sprot"

# use the RE provided utility to unpack the database to fast local disk
prepare_db $dbname.tar.gz

# display the number of threads selected by the RE
echo "Running with $BLAST_NUM_CPUS cpus"

# display the unpacked database location
echo "BLASTDB points to $BLASTDB"

# finally to the analysis
blastall -a $BLAST_NUM_CPUS -p blastp -d $dbname.fasta -i input_sequence
exitcode=$?

echo "Bye BLAST!"

# Exit with the exit code from the BLAST binary. Without this, the exit status
# from 'echo' would be returned to the grid middleware and all the jobs would
# be recorded as successful.
exit $exitcode
