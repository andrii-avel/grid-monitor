#!/bin/sh -v
#$ -cwd

export ELMER_HOME=.
 
tar -p -z -x -f unchangebles.tar.gz
./lib/ld-linux.so.3 --library-path "./lib" ./ElmerSolver

