#!/bin/sh
povray -d -ochair.png chair.pov
povray -d -odrink.png drink.pov
povray -d -oegg.png egg.pov
