#!/bin/sh
povray -d -kff5 -ki0.00 -kf0.08 -ofractalzoom_part1_frame fractalzoom.pov
tar czvf fractalzoom_part1_frames.tar.gz fractalzoom_part1_frame*.png
