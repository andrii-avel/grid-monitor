#! /bin/sh
povray $@
