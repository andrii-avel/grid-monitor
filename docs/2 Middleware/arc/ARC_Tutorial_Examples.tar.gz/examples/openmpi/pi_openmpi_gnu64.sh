echo "mpi command follows:" $MPIRUN $MPIARGS "pi_openmpi_gnu64.bin" $*
/usr/bin/time -p $MPIRUN $MPIARGS pi_openmpi_gnu64.bin $*
