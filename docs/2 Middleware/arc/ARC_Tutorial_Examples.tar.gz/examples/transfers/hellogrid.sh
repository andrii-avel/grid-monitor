#!/bin/sh
echo "Hello Grid!"
# Sleep for a while so that users can try monitoring the job
sleep 10

